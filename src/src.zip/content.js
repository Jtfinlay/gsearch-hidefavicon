let favicons = document.getElementsByClassName("xA33Gc");
while (favicons[0]) favicons[0].parentNode.removeChild(favicons[0]);

favicons = document.getElementsByClassName("K7JcSb");
while (favicons[0]) favicons[0].parentNode.removeChild(favicons[0]);
